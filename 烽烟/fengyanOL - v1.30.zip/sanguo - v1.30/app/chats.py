#coding:utf8
'''
Created on 2013-9-5

@author: jt
'''
from app.chatServer import initapp
initapp.loadModule()