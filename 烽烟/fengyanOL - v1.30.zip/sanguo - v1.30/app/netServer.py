#coding:utf8
'''
Created on 2013-9-5

@author: jt
'''
from app.net import initapp
initapp.loadModule()