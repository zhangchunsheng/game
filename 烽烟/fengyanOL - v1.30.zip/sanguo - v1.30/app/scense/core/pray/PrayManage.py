#coding:utf8
'''
Created on 2012-7-16
祷告管理
@author: jt
'''
from app.scense.core.singleton import Singleton
from app.scense.utils import dbaccess
from app.scense.applyInterface import configure
from app.scense.netInterface import pushObjectNetInterface
import time
import datetime
from app.scense.core.language.Language import Lg



class PrayManage():
    '''祷告管理'''

    __metaclass__ = Singleton

    def __init__(self):
        ''''''
        self.mc = dbaccess.memclient
        self.CXk=set([])#存储内存中的key 
        #  value{'gold':数量,'counts':次数}
        self.key="PrayManage#zs" #值是self.CXk
        
        
        self.gg=[] #n倍奖励信息  最多4条记录 [str,str]
        self.ggkey='prayGGkey' #存储self.gg
        
    def clean0(self):
        '''清空内存数据'''
        self.mc.delete_multi(list(self.CXk))
        
    def getGG(self):
        '''获取n倍奖励信息'''
        info=self.mc.get(self.ggkey)
        if not info:
            info=[]
        infolist=[]
        self.gg=[]
        for item in info:
            timestr=item[0] #2012-07-18 15:54:02
            str=item[1]
            
            st=time.strptime(timestr,"%Y-%m-%d %X")
            date=datetime.datetime( *st[:6] ) 
            ss=datetime.datetime.now()
            a4=ss-date
            count=int(a4.days)
            if count==0:
                str=Lg().g(560)%date.strftime(Lg().g(561))+str
            elif count==1:
                str=Lg().g(562)+str
            else:
                str=Lg().g(563)+str
            infolist.append(str)
            self.gg.append(item)
        return infolist
    
    def uploadGG(self,info):
        '''将信息保存在共享内存中'''
        self.mc.set(self.ggkey,info)
        
    def getkey(self,pid):
        '''生成内存key'''
        str="PrayManage#zs#key%s"%pid
        return str
        