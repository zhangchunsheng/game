#coding:utf8
'''
Created on 2011-6-21

@author: lan
'''
from app.scense.core.singleton import Singleton
class BeginnerManager:
    '''新手管理器'''
    __metaclass__ = Singleton
    
    