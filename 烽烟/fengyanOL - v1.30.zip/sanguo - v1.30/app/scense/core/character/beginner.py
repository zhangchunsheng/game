#coding:utf8
'''
Created on 2011-6-21

@author: lan
'''
class Beginner:
    '''新手引导角色'''