#coding:utf8
'''
Created on 2012-5-17
官爵
@author: jt
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage

@nodeHandle
def getNobility_3300(dynamicId,request_proto):
    '''获取爵位面板所有信息'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    
@nodeHandle
def getNobility_3301(dynamicId,request_proto):
    '''领取俸禄'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def getNobility_3302(dynamicId,request_proto):
    '''升级爵位'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def getNobility_3303(dynamicId,request_proto):
    '''获取威望任务'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    
@nodeHandle
def getNobility_3304(dynamicId,request_proto):
    '''上交物品换取威望'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    
@nodeHandle
def getNobility_3305(dynamicId,request_proto):
    '''上交钻换取威望'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def getNobility_3306(dynamicId,request_proto):
    '''返回客户端这次点击贡献应该花费多少钻'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
