#coding:utf8
'''
Created on 2012-7-18

@author: Administrator
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import  pushOtherMessage

@nodeHandle
def GetCurLevelInfo_4200(dynamicId, request_proto):
    '''获取当前塔层信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])
    
    

@nodeHandle
def RefreshInfo_4201(dynamicId, request_proto):
    '''刷新塔层信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])
    

@nodeHandle
def AutoPaTa_4202(dynamicId, request_proto):
    '''自动爬塔
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])

@nodeHandle
def TowerBattle_4203(dynamicId, request_proto):
    '''爬塔战斗
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])


