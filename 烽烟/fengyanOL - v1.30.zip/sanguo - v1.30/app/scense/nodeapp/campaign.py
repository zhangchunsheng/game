#coding:utf8
'''
Created on 2012-9-11

@author: Administrator
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage

@nodeHandle
def GetGroupLingDiInfo_4400(dynamicId, request_proto):
    '''获取国领地信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def ObtainJiangLi_4401(dynamicId, request_proto):
    '''获取国领地奖励
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])


@nodeHandle
def GetCityListInfo_4402(dynamicId, request_proto):
    '''获取城镇征战列表
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    

@nodeHandle
def GroupPK_4403(dynamicId, request_proto):
    '''国战申请
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetXuYuanInfo_4404(dynamicId, request_proto):
    '''获取许愿信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def UseXingYun_4405(dynamicId, request_proto):
    '''使用幸运许愿
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetBattleInfo_4406(dynamicId, request_proto):
    '''获取国战的信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def Participate_4407(dynamicId, request_proto):
    '''角色参战
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def AutoJoinBattle_4408(dynamicId, request_proto):
    '''自动参战或取消自动参战
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def CancelBattle_4409(dynamicId, request_proto):
    '''角色参战
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])




    
    