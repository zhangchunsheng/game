#coding:utf8
'''
Created on 2012-7-16
祈祷
@author: jt
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage

@nodeHandle
def pray_4100(dynamicId, request_proto):
    '''获取祈祷信息'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])    