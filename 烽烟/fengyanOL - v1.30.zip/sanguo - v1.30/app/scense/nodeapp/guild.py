#coding:utf8
'''
Created on 2011-5-26

@author: sean_lan
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage


@nodeHandle
def getGuildListInfo_1301(dynamicId,request_proto):
    '''获取行会列表'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    
    
@nodeHandle
def creatGuild_1302(dynamicId,request_proto):
    '''创建行会'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    
@nodeHandle
def AcceptOrRefuseApply_1304(dynamicId,request_proto):
    '''拒绝或同意申请'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def AppliOrUnsubscribe_1305(dynamicId,request_proto):
    '''申请加入国和取消
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def TransferCorpsOrKickMember_1306(dynamicId,request_proto):
    '''移交国长或开除成员'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def ModifyCorpsAnnoun_1307(dynamicId,request_proto):
    '''修改公告'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def CrusadeCorps_1308(dynamicId,request_proto):
    '''行会战申请'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetEmblemInfo_1310(dynamicId,request_proto):
    '''获取行会管理信息'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def LevelUpEmblem_1311(dynamicId,request_proto):
    '''升级军徽'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def ModifyBugle_1312(dynamicId,request_proto):
    '''修改军号'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetCorpsTechnologyListInfo_1314(dynamicId,request_proto):
    '''获取科技列表'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    
@nodeHandle
def CorpsTechnologyDonate_1315(dynamicId,request_proto):
    '''捐献'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def LeaveCorps_1309(dynamicId,request_proto):
    '''离开行会'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def TakeCorpsChief_1313(dynamicId,request_proto):
    '''接位国长'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def ModifyDefaultDonate_1316(dynamicId,request_proto):
    '''修改科技捐献设置'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetCorpsMemberListInfo_1303(dynamicId,request_proto):
    '''获取成员列表信息'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetCorpsAppliListInfo_1317(dynamicId,request_proto):
    '''获取申请列表'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def UnionInviteOther_1318(dynamicId,request_proto):
    '''邀请加入行会'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
 
@nodeHandle
def CorpsInviteReply_1320(dynamicId,request_proto):
    '''行会邀请的反馈'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetSingleUnionInfo_1322(dynamicId,request_proto):
    '''获取单个国的信息'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def ChangeUnionColor_2503(dynamicId,request_proto):
    '''改变行会标识颜色'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    
@nodeHandle
def ModifyJoinLevel_1324(dynamicId,request_proto):
    '''修改国加入等级限制'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    
