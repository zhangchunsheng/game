#coding:utf8
'''
Created on 2012-5-21

@author: Administrator
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage

@nodeHandle
def GetAllHeChengInfos_2114(dynamicId,request_proto):
    '''获取所有的合成信息'''

    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])
    
@nodeHandle
def GetOneItemHeChengInfo_2115(dynamicId,request_proto):
    '''获取某个物品的合成信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])
    

@nodeHandle
def Hecheng_2116(dynamicId,request_proto):
    '''物品合成
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.5版本", [dynamicId])
    
    