#coding:utf8
'''
Created on 2012-5-7

@author: Administrator
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.applyInterface import schedule
from app.scense.protoFile.schedule import GetTargetInfo3203_pb2
from app.scense.protoFile.schedule import ObtainTargetReward3204_pb2
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage

@nodeHandle
def GetCalendarTaskListInfo_3100(dynamicId, request_proto):
    '''获取日程信息'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def ReceivedCalendarBound_3101(dynamicId, request_proto):
    '''领取日程奖励
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])

@nodeHandle
def GetTargetInfo_3203(dynamicId,request_proto):
    '''获取所有的每日目标
    '''
    argument = GetTargetInfo3203_pb2.GetTargetInfoRequest()
    argument.ParseFromString(request_proto)
    response = GetTargetInfo3203_pb2.GetTargetInfoResponse()
    characterId = argument.id
    data = schedule.GetTargetInfo(characterId)
    response.result = data.get('result',False)
    response.message = data.get('message','')
    if data.get('data',None):
        alltargetlist = data.get('data')
        dayTaskInfo = response.dayTaskInfo
        for dayInfo in alltargetlist:
            daytarget = dayTaskInfo.add()
            daytarget.isSucFlag = dayInfo.get('isSucFlag',False)
            daytarget.isOpenFlag = dayInfo.get('isOpenFlag',False)
            dayListTaskInfo = daytarget.dayListTaskInfo
            for target in dayInfo.get('dayListTaskInfo',[]):
                targetinfo = dayListTaskInfo.add()
                targetinfo.taskId = target.get('taskId',0)
                targetinfo.isCompleteFlag = target.get('isCompleteFlag',False)
                targetinfo.icon = target.get('icon','0')
                targetinfo.taskDes = target.get('taskDes',u'').decode('utf8')
                targetinfo.isObtainFlag = target.get('isObtainFlag',False)
                rewardInfo = targetinfo.rewardInfo
                for _reward in target.get('rewardInfo',[]):
                    reward = rewardInfo.add()
                    reward.itemId = _reward.get('itemId',0)
                    reward.icon = _reward.get('icon',0)
                    reward.stack = _reward.get('stack',0)
                    reward.type = _reward.get('type',0)
                    reward.rewardType = _reward.get('rewardType',0)
    return response.SerializeToString()
                
@nodeHandle
def ObtainTargetReward_3204(dynamicId,request_proto):
    '''领取每日目标奖励'''
    argument = ObtainTargetReward3204_pb2.ObtainTargetRewardRequest()
    argument.ParseFromString(request_proto)
    response = ObtainTargetReward3204_pb2.ObtainTargetRewardResponse()
    characterId = argument.id
    taskId = argument.taskId
    data = schedule.ObtainTargetReward(characterId, taskId)
    response.result = data.get('result',False)
    response.message = data.get('message','')
    return response.SerializeToString()
    
    