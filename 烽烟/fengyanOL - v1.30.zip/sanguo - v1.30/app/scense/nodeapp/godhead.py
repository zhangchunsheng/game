#coding:utf8
'''
Created on 2012-5-15

@author: Administrator
'''

from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage

@nodeHandle
def GetShenChiInfo_3400(dynamicId,request_proto):
    '''获取神格信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])


@nodeHandle
def ActiveShenGe_3401(dynamicId,request_proto):
    '''激活神格'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
        
        
        
        