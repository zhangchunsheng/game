#coding:utf8
'''
Created on 2012-6-7

@author: Administrator
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage

@nodeHandle
def GetXingYunList_3600(dynamicId, request_proto):
    '''获取星运信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def ZhanXing_3601(dynamicId, request_proto):
    '''开始占星
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def YiJianObtainAndDrop_3602(dynamicId, request_proto):
    '''一键拾取或卖出
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    
@nodeHandle
def YiJianZhanXing_3603(dynamicId, request_proto):
    '''一键占星
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def GetRoleAndPetList_3604(dynamicId, request_proto):
    '''获取角色和宠物的星运装备栏信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def GetPackXingYunListInfo_3605(dynamicId, request_proto):
    '''获取星运包裹信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    
@nodeHandle
def YiJianHeCheng_3606(dynamicId, request_proto):
    '''一键合成'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    
@nodeHandle
def OpeXingXun_3607(dynamicId, request_proto):
    '''星运移动'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def JiFeng_3609(dynamicId, request_proto):
    '''获取积分商城信息
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
            
@nodeHandle
def QueRenExchange_3610(dynamicId, request_proto):
    '''积分兑换星运
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    
    
    
