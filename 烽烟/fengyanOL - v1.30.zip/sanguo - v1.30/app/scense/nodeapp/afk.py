#coding:utf8
'''
Created on 2012-4-12

@author: Administrator
'''
from app.scense.serverconfig.node import nodeHandle
from app.scense.protoFile.afk import SaoDang3205_pb2
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage
from app.scense.applyInterface import afk


@nodeHandle
def GetWaJueInfo_2800(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def StartWaJue_2801(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def DianShiChengJin_2802(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def LevelUpSpeedWaJue_2803(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def NowSuccWaJue_2804(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def GetAramListInfo_2805(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def AramStartXunLian_2806(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def AramJiaJiXunLian_2807(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])
    

@nodeHandle
def AramStartXunLian_2808(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def AramNowSuccXunLian_2809(dynamicId, request_proto):
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.6版本", [dynamicId])

@nodeHandle
def SaoDang_3205(dynamicId, request_proto):
    '''扫荡
    '''
    argument = SaoDang3205_pb2.SaoDangRequest()
    argument.ParseFromString(request_proto)
    response = SaoDang3205_pb2.SaoDangResponse()
    characterId = argument.id
    fubenId = argument.fubenId
    sdType = argument.sdType
    sdRound = argument.sdRound
    data = afk.Saodang(characterId, fubenId, sdType, sdRound)
    response.result = data.get('result',False)
    response.message = data.get('message','')
    if data.get('data',None):
        msglist = data.get('data')
        for msg in msglist:
            baInfo = response.baInfoList.add()
            baInfo.baDesStr = msg
    return response.SerializeToString()
    


