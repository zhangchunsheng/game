#coding:utf8
'''
Created on 2012-5-3
角色每日日程表
开服目的表
@author: Administrator
'''
from app.scense.component.Component import Component
from app.scense.utils.dbopera import dbSchedule

import datetime
from app.scense.core.language.Language import Lg

#日程字典
SCHEDULE_DICT = {}

class CharacterScheduleComponent(Component):
    
    def __init__(self,owner):
        '''初始化
        @param schedule: dict 今日进度
        '''
        Component.__init__(self, owner)
        self.schedule = {}
        self.initSchedule()
        
    def initSchedule(self):
        '''初始化今日进度'''
        characterId = self._owner.baseInfo.id
        self.schedule = dbSchedule.getTodaySchedule(characterId)
        
    def noticeSchedule(self,scheduleType,goal = 1):
        '''进度通知
        @param scheduleType: int 进度类型
        '''
        schedule = dbSchedule.SCHEDULE_CONFIG.get(scheduleType)
        if not schedule:
            return 
        if self.schedule.get('schedule_%d'%scheduleType)>=schedule.get('schedule_goal',1):
            return
        scheduletag = 'schedule_%d'%scheduleType
        self.schedule[scheduletag] +=goal
        if self.schedule[scheduletag]>schedule.get('schedule_goal',1):
            self.schedule[scheduletag] = schedule.get('schedule_goal',1)
        props = {}
        props[scheduletag] = self.schedule[scheduletag]
        if self.schedule[scheduletag]>=schedule.get('schedule_goal',1):
            activityadd = schedule.get('schedule_activity',0)
            self.schedule['activity'] += activityadd
            props['activity'] = self.schedule['activity']
        dbSchedule.updateSchedule(self._owner.baseInfo.id, props)
        

    
        
