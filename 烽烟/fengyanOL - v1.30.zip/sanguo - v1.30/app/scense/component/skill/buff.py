#coding:utf8
'''
Created on 2011-8-30

@author: lan
'''

class Buff(object):
    '''Buff特效'''
    
    def __init__(self,id):
        '''buff init'''
        self.id = id