#coding:utf8
'''
Created on 2011-5-25

@author: sean_lan
'''
from app.scense.core.PlayersManager import PlayersManager
from app.scense.core.guild.GuildManager import GuildManager
from app.scense.utils import dbaccess
from app.scense.utils.dbopera import dbGuild
from app.scense.netInterface.pushObjectNetInterface import pushInviteOtherJoinGuild,pushOtherMessage
from app.scense.netInterface.pushPrompted import pushPromptedMessage
from app.scense.core.language.Language import Lg

AllCharacterGuildInfo={} #存储角色与行会对应关系
LEVELREQUIRED = 12

        
def CorpsInviteReply(dynamicId,characterId,union_id,is_ok):
    '''邀请加入行会的反馈信息
    @param dynamicId: int 客户端的动态id
    @param characterId: int 角色的id
    @param union_id: int 行会的id(邀请者的ID)
    @param is_ok: int 是否同意 0否 1是
    '''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    
def GetSingleUnion(dynamicId,characterId,union_id):
    '''获取单个国的信息'''
    pushOtherMessage(905, u"该功能暂未开放,敬请期待V1.4版本", [dynamicId])
    


