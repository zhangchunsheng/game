#coding:utf8
'''
Created on 2012-7-18
爬塔
@author: Administrator
'''

