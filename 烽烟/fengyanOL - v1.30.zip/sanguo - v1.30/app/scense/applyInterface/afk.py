#coding:utf8
'''
Created on 2012-4-12

@author: Administrator
'''
from app.scense.core.PlayersManager import PlayersManager
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessageByCharacterId
from app.scense.core.language.Language import Lg

def Saodang(characterId,fubenId,sdType,sdRound):
    '''扫荡
    @param characterId: int 角色的ID
    @param fubenId: int 副本的ID
    @param sdType: int 扫荡类型
    @param sdRound: int 扫荡回合数
    '''
    player = PlayersManager().getPlayerByID(characterId)
    if not player:
        return {'result':False,'messge':Lg().g(18)}
    if sdType == 0:
        rounds = 0
    else:
        rounds = sdRound
    result = player.raids.doRaids(rounds,fubenId)
    msg = result.get('message',u'')
    if msg:
        pushOtherMessageByCharacterId(msg, [characterId])
    return result

    
    

