#coding:utf8
'''
Created on 2012-9-11

@author: Administrator
'''
from app.scense.core.campaign.FortressManager import FortressManager
from app.scense.core.guild.GuildManager import GuildManager
from app.scense.core.PlayersManager import PlayersManager
from app.scense.core.language.Language import Lg



def ObtainJiangLi4401(dynamicId,characterId):
    '''领取奖励殖民'''
    player = PlayersManager().getPlayerByID(characterId)
    if not player or not player.CheckClient(dynamicId):
        return {'result':False,'message':Lg().g(18)}
    guildId = player.guild.getID()
    if not guildId:
        return {'result':False,'message':Lg().g(79)}
    ldID = FortressManager().getGuildFortressId(guildId)
    if not ldID:#没有领地
        return {'result':False,'message':Lg().g(657)}
    result = player.guild.ObtainFortressReward()
    msgID = result.get('msgID',0)
    message = u''
    if msgID:
        message = Lg().g(msgID)
    return {'result':result.get('result',False),'message':message}


    

    

    

    



    


