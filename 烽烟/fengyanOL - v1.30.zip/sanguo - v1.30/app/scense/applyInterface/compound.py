#coding:utf8
'''
Created on 2012-5-21
物品合成
@author: Administrator
'''
