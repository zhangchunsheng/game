#coding:utf8
'''
Created on 2011-5-13

@author: sean_lan
'''
from app.scense.core.PlayersManager import PlayersManager
from app.scense.netInterface.pushObjectNetInterface import pushOtherMessage
from app.scense.utils import dbaccess
from app.scense.core.language.Language import Lg

def getMailList(dynamicId,characterId,mailType,pageCount):
    '''获取邮件列表
    @param characterId: int 角色的ID
    @param mailType: int 邮件的类型
    @param pageCount: int 页面数
    '''
    player = PlayersManager().getPlayerByID(characterId)
    if not player or not player.CheckClient(dynamicId):
        return {'result':False,'message':Lg().g(18)}
    mailListInfo = player.mail.getMailList(mailType,pageCount)
    return {'result':True,'data':mailListInfo}

def getMailInfo(dynamicId,characterId,mailID):
    '''获取邮件的详细信息
    @param characterId: int 角色的ID
    @param mailID: int 邮件的ID
    '''
    player = PlayersManager().getPlayerByID(characterId)
    if not player or not player.CheckClient(dynamicId):
        return {'result':False,'message':Lg().g(18)}
    mailInfo = player.mail.readMail(mailID)
    return mailInfo

def SaveAndDeleteMail(dynamicId,characterId,setType,requestInfo,mailId,responseMailType):
    '''删除或保存邮件
    @param characterId: int 角色的ID
    @param setType: int 操作类型 0保存1删除单条数据2删除一页数据
    @param requestInfo: int 单条时的邮件ID
    @param mailId: （int）list 批量时邮件的ID列表 
    '''
    player = PlayersManager().getPlayerByID(characterId)
    if not player or not player.CheckClient(dynamicId):
        return {'result':False,'message':Lg().g(18)}
    if setType ==0:
        result = player.mail.saveMail(requestInfo)
    elif setType==1:
        result = player.mail.deleteMail(requestInfo)
    else:
        result = player.mail.BatchDelete(mailId)
    if result['result']:
        pgcnd = player.mail.getPageCnd(responseMailType)
        result['data']={}
        result['data']['maxPage'] = pgcnd
        result['data']['setTypeResponse'] = setType
    return result

def sendMail(dynamicId,characterId,playerName,title,content):
    '''添加邮件
    @param dynamicId: int 客户端的动态id
    @param characterId: int 角色的id
    @param playerName: str 发送人的名称
    @param content: str 邮件内容
    @param title: str 标题
    '''
    player = PlayersManager().getPlayerByID(characterId)
    if not player or not player.CheckClient(dynamicId):
        return {'result':False,'message':Lg().g(18)}
    for word in dbaccess.All_ShieldWord:
        if title.find(word[0])!=-1:
            msg = Lg().g(151)
            pushOtherMessage(905, msg,[dynamicId])
            return {'result':False,'message':u''} 
    for word in dbaccess.All_ShieldWord:
        if content.find(word[0])!=-1:
            msg = Lg().g(151)
            pushOtherMessage(905, msg,[dynamicId])
            return {'result':False,'message':Lg().g(151)}
    if len(title)>12:
        msg = Lg().g(152)
        pushOtherMessage(905, msg,[dynamicId])
        return {'result':False,'message':u''}
    toId = dbaccess.getCharacterIdByNickName(playerName)
    if not toId:
        msg = Lg().g(153)
        pushOtherMessage(905, msg,[dynamicId])
        return {'result':False,'message':u''}
    if toId[0]==characterId:
        msg = Lg().g(154)
        pushOtherMessage(905, msg,[dynamicId])
        return {'result':False,'message':u''}
    result = player.mail.sendMail(toId[0],title,content)
    if  result:
        msg = Lg().g(155)
        pushOtherMessage(905, msg,[dynamicId])
        return {'result':True,'message':msg}
    return {'result':False,'message':Lg().g(156)}


