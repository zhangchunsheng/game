#coding:utf8
'''
Created on 2011-3-31

@author: sean_lan
'''
from app.gate.utils.dbpool import DBPool

database = ''
dbpool = DBPool()
servername = ''
memclient = None

