#coding:utf8
'''
Created on 2013-9-5

@author: jt
'''
from app.gate import initapp
initapp.loadModule()