#coding:utf8
'''
Created on 2013-9-4

@author: hg (www.9miao.com)
'''
from admin import initconfig
 
initconfig.loadModule()
