#coding:utf8
'''
Created on 2013-8-13

@author: lan (www.9miao.com)
'''
from dbfront import initconfig

initconfig.loadModule()