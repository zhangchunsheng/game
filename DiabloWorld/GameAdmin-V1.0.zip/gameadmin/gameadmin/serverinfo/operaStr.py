#coding:utf8
'''
Created on 2013-9-10

@author: hg (www.9miao.com)
'''

operaStrDict = {1:'player.finance.addCoin(%s)',
                2:'player.level.addExp(%s)',
                3:'player.finance.addGold(%s)',
                4:'player.level.addVipExp(%s)',
                5:'player.attribute.addEnergy(%s)',
                6:'player.level.setLevel(%s)',
                7:'player.pack.putNewItemsInPackage(%s,%s)',
                8:'player.pet.addPet(%s,level=%s)'}
'''后台操作账号的脚本
'''